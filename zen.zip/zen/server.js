var express = require('express')
    , morgan = require('morgan')
    , bodyParser = require('body-parser')
    , methodOverride = require('method-override')
    , app = express()
    , port = process.env.PORT || 3000
    , router = express.Router();
  var credentials = {
    accessKeyId: process.env.aki,
    secretAccessKey: process.env.sak,
    region: "us-east-1"
};
var dynasty = require('dynasty')(credentials),
		tbl = dynasty.table('zen');

app.use(express.static(__dirname + '/views')); // set the static files location for the static html
app.use(express.static(__dirname + '/public')); // set the static files location /public/img will be /img for users
app.use(morgan('dev'));                     // log every request to the console
app.use(bodyParser());                      // pull information from html in POST
app.use(methodOverride());                  // simulate DELETE and PUT

router.get('/', function(req, res, next) {
    res.render('index.html');
});
router.get('/draw', function(req, res, next) {
    res.render('draw.html');
});
var dataexample = `
[0.7320056838989257,0.4440056838989258,0.7180056838989258,0.7900056838989258,0.5240056838989258][0.43933523559570314,0.32333523559570315,0.7953352355957031,0.7213352355957031,0.4533352355957031]
`
var start = `
{ "xaxis": 
`
var middle = `
, "yaxis": 
`
var end = "}"
// GET method route
app.get('/coordinates', function (req, res) {
  /// Query for most recent coordinates in data store. table. Return coordinates.
  tbl.find('current')
    .then(function(design) {
        res.send(design.coords)
    });
})

app.get('/logdb', function (req, res) {
  res.send('GET request to the homepage')
})
app.get('/shape/:shape', function (req, res) {
  res.send(req.params.x)
})

app.get('/data/:x/:y', function (req, res) {
  /// Capture and store data from XMLHTTPrequest in DynamoDB. https://sheltered-tundra-18217.herokuapp.com/data/[1]/[2]
var coords = start + req.params.x + middle + req.params.y + end
tbl.update( {hash: "current" }, { coords: coords });
  res.send(coords)
})

app.use('/', router);

app.listen(port);
console.log('App running on port', port);