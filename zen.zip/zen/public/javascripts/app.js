// App js
(function() {
	var go = 'running!';
	console.log( go );
})();
